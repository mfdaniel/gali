This font is PERSONAL ONLY and is not allowed for commercial purposes,
I am very happy if I can appreciate from you guys.

Paypal account for donation : https://paypal.me/emdeen

For Commercial Use,
Please send email to emtheen@gmail.com
Or you can buy it here :
https://creativemarket.com/dimsngrho/2274929-Menulist-Typeface


*Use without permission will be subject to more payments 10x the normal price

===================================

Support
----------

Mail support : emtheen@gmail.com
Facebook : https://www.facebook.com/mastinG00D
Instagram : instagram.com/dimsngrho
Behance :https://www.behance.net/dimsngrho

===================================

Muhammad Dimas | Dimsngrho
Tangerang - Indonesia.
